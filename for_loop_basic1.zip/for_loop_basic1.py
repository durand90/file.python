for x in range(151):
    print(x)

for x in range(5, 1001, 5):
    print(x)

for y in range(1, 101):
    if y % 10 == 0:
        print("Coding Dojo")
    elif y % 5 == 0:
        print("Coding")
    else: 
        print(y)

add=0
for x in range(1, 500001, 2):
    print(add)
    add += x

z = 2018
while z > 0:
    print(z)
    z = z - 4

for x in range(2, 27, 4):
    print(x)
